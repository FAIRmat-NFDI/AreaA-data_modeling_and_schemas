# Area A: sample preparation data

## Base Sections (or Base Classes):

![Base Classes](https://box.hu-berlin.de/f/609490a1c373425babdb/?dl=1)

These base section have got an <em>a priori</em> **inheritance** structure. The user can further decide how to put together this bricks by means of **referencing**. 
